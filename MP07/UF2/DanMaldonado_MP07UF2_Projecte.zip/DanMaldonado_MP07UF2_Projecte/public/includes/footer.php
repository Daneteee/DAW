<footer>
    <p>&copy; 2024 DaneBlog. Tots els drets reservats.</p>
</footer>
</body>
</html>
