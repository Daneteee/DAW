<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-2xl mx-auto px-4 py-6">
        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="mb-6 border rounded-lg p-4 shadow bg-white dark:bg-gray-200 relative">
                <!-- Enlace "Ver Post" en la esquina superior derecha -->
                <a href="<?php echo e(route('images.show', $image->id)); ?>" class="absolute top-4 right-4 text-blue-500 text-sm font-semibold hover:text-blue-700">
                    Ver Post
                </a>

                <div class="flex items-center justify-between">
                    <div>
                        <strong><?php echo e($image->user->name); ?> <?php echo e($image->user->surname); ?></strong>
                        <span class="text-gray-500 text-sm">· <?php echo e($image->created_at->diffForHumans()); ?></span>
                    </div>
                </div>

                <div class="mt-4">
                    <img src="<?php echo e(asset('storage/' . $image->image_path)); ?>" alt="Image" class="w-[500px] rounded mx-auto">
                </div>

                <p class="mt-2 text-gray-800"><?php echo e($image->description); ?></p>

                <div class="flex items-center gap-4 mt-3 text-gray-600">
                    <button onclick="toggleLike(<?php echo e($image->id); ?>)" id="like-button-<?php echo e($image->id); ?>">
                        <?php
                            $liked = $image->likes->contains('user_id', auth()->id());
                        ?>
                        <i class="fa-heart fa-regular <?php echo e($liked ? 'fa-solid text-red-500' : ''); ?>"></i>
                        <span id="like-count-<?php echo e($image->id); ?>"><?php echo e($image->likes->count()); ?></span>
                    </button>

                    <span><i class="fa-regular fa-comment"></i> <?php echo e($image->comments->count()); ?></span>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="mt-6">
            <?php echo e($images->links()); ?>

        </div>
    </div>

    <script>
        function toggleLike(imageId) {
            fetch(`/images/${imageId}/like`, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                },
            })
            .then(res => res.json())
            .then(data => {
                const heartIcon = document.querySelector(`#like-button-${imageId} i`);
                const likeCount = document.getElementById(`like-count-${imageId}`);

                if (data.liked) {
                    heartIcon.classList.add('fa-solid', 'text-red-500');
                } else {
                    heartIcon.classList.remove('fa-solid', 'text-red-500');
                }

                likeCount.textContent = data.likes_count;
            });
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /srv/http/MP07/UF4/DanMaldonado_MP07UF4_Projecte/resources/views/home.blade.php ENDPATH**/ ?>