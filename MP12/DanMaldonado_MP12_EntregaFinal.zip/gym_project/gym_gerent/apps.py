from django.apps import AppConfig


class GymGerentConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gym_gerent'
