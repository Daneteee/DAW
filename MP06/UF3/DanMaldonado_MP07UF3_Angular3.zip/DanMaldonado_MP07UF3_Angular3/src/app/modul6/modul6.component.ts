import { Component } from '@angular/core';
import { UnitatsFormativesComponentComponent } from '../unitats-formatives-component/unitats-formatives-component.component';

@Component({
  selector: 'app-modul6',
  imports: [UnitatsFormativesComponentComponent],
  templateUrl: './modul6.component.html',
  styleUrl: './modul6.component.css'
})
export class Modul6Component {
    subtitol: string = "versio 24-25"
}
