import { Component } from '@angular/core';

@Component({
  selector: 'app-uf',
  imports: [],
  templateUrl: './unitats-formatives-component.component.html',
  styleUrl: './unitats-formatives-component.component.css'
})
export class UnitatsFormativesComponentComponent {

}
