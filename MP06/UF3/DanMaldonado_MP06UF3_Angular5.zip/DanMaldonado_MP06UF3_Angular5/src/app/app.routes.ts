import { Routes } from '@angular/router';
import { FormulariPostComponent } from './formulari-post/formulari-post.component';

export const routes: Routes = [
  { path: 'formulari-post', component: FormulariPostComponent }
];