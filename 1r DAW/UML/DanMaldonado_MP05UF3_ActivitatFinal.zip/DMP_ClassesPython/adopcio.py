class Adopcio:
    def __init__(self, ID_adopcio, gos, client, estat, data_adopcio):
        self.ID_adopcio = ID_adopcio
        self.gos = gos
        self.client = client
        self.estat = estat
        self.data_adopcio = data_adopcio

        