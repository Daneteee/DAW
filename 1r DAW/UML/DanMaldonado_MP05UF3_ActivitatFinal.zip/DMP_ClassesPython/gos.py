class Gos:
    def __init__(self, xip, nom, edat, raca):
        self.xip = xip
        self.nom = nom
        self.edat = edat
        self.raca = raca