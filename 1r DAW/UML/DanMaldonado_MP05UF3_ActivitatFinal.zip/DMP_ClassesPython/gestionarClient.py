class GestionarClient:
    def __init__(self, gos):
        self.gos = gos

    def alta_client(self):
        pass

    def modificar_client(self):
        pass

    def baixa_client(self):
        pass