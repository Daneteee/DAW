class GestionarAdopcio:
    def __init__(self, adopcio):
        self.adopcio = adopcio

    def contractar_adopcio(self):
        apte = self.adopcio.client.apte
        pass

    def modificar_adopcio(self):
        pass

    def baixa_adopcio(self):
        pass

    def buscar_llar(self):
        pass

    def concertar_visita(self):
        pass

    def confirmar_adopcio(self):
        pass

    def questionari(self):
        pass