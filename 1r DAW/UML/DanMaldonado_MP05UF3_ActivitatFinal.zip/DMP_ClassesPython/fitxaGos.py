from fitxaInformacio import FitxaInformacio


class FitxaGos(FitxaInformacio):
    def __init__(self, gos):
        super().__init__(gos)