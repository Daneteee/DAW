class GestionarGos:
    def __init__(self, gos):
        self.gos = gos

    def alta_gos(self):
        pass

    def modificar_gos(self):
        pass

    def baixa_gos(self):
        pass