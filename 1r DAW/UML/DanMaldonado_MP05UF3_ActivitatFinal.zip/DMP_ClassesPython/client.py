class Client:
    def __init__(self, DNI, nom, edat, gos_edat_pref, gos_raca_pref, apte):
        self.DNI = DNI
        self.nom = nom
        self.edat = edat
        self.gos_edat_pref = gos_edat_pref
        self.gos_raca_pref = gos_raca_pref
        self.apte = apte