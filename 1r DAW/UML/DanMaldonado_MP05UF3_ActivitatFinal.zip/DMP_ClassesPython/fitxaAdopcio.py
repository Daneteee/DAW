from fitxaInformacio import FitxaInformacio


class FitxaAdopcio(FitxaInformacio):
    def __init__(self, adopcio):
        super().__init__(adopcio)