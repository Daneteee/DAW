class FitxaInformacio:
    def __init__(self, objecte):
        self.objecte = objecte

    def mostrar_fitxa(self):
        pass