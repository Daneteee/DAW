Projecte de M3 - UF6 per Dan Maldonado

Link al video:
https://drive.google.com/file/d/16HVCHGWO6-96zDcHT_wtKRak9mfDeLsw/view?usp=sharing